# 
# Exemplo de como processar dados provenientes de um JSON
#

import urllib.request  
import json

