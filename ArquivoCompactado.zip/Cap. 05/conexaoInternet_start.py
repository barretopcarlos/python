# 
# Arquivo com exemplos para manipulação de dados na Internet
#

import urllib.request



