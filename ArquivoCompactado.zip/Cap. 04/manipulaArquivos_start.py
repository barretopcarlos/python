#
# Exemplos de como trabalhar com arquivos
#
import os
from os import path
import shutil

