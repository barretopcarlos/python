#
# Exemplo de código para escrever Hello World!
#

print("Hello World")

f = 0
print(f)