#
# Arquivo com exemplos de Loops
#

# Definindo um Loop WHILE
def loopWhile():
    x = 0 
    while (x < 5):
        print(x)
        x = x + 1 

loopWhile()