#
# Arquivo de exemplo das estruturas condicionais
#

def Condicionais():
    x, y = 1000, 1000

    if(x < y):
        print("x é menor do que y")
    elif (x == y):
        print ("x é igual a y")
    else:
        print("x é maior do que y")

Condicionais()