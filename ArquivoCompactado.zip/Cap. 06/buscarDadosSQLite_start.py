# 
# Exemplo de acesso a uma base de dados SQLite
#

import sqlite3

